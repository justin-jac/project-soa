from flask import Flask, render_template, Response as HTTPResponse, request as HTTPRequest
import mysql.connector
import mysql.connector, json, pika, logging
from flask_cors import CORS
# from kantin_producer import *

db = mysql.connector.connect(host="localhost", user="root", password="", database="orderdb")
dbc = db.cursor(dictionary=True)


app = Flask(__name__)
CORS(app)
# Note, HTTP response codes are
#  200 = OK the request has succeeded.
#  201 = the request has succeeded and a new resource has been created as a result.
#  401 = Unauthorized (user identity is unknown)
#  403 = Forbidden (user identity is known to the server)
#  409 = A conflict with the current state of the resource
#  429 = Too Many Requests


@app.route('/order', methods = ['POST', 'GET'])
def order():
    jsondoc = ''

    #region GET Order
    # ------------------------------------------------------
    # HTTP method = GET
    # ------------------------------------------------------
    if HTTPRequest.method == 'GET':
        auth = HTTPRequest.authorization
        print(auth)

        # ambil data kantin
        sql = "SELECT * FROM orders"
        dbc.execute(sql)
        data_orders = dbc.fetchall()

        if data_orders != None:
            for order in data_orders:
                order['tanggalOrder'] = str(order['tanggalOrder'])
            # kalau data order ada, juga ambil menu dari kantin tsb.
            # for x in range(len(data_orders)):
            #     kantin_id = data_orders[x]['id']
            #     sql = "SELECT * FROM orders WHERE idresto = %s"
            #     dbc.execute(sql, [kantin_id])
            #     data_menu = dbc.fetchall()
            #     data_orders[x]['produk'] = data_menu

            status_code = 200  # The request has succeeded
            jsondoc = json.dumps(data_orders)

        else:
            status_code = 404  # No resources found
    #endregion

    #region POST Order
    # ------------------------------------------------------
    # HTTP method = POST
    # ------------------------------------------------------
    elif HTTPRequest.method == 'POST':
        data = json.loads(HTTPRequest.data)

        id_client = data["idClient"]
        nama_order = data["namaOrder"]
        desk_order = data["deskripsiOrder"]
        tgl_order = data["tanggalOrder"]
        total_order = data["totalHargaOrder"]
        stat_order = data["statusOrder"]

        try:
            # simpan nama kantin, dan gedung ke database

            sql = "INSERT INTO orders (idClient, namaOrder,deskripsiOrder, tanggalOrder, totalHargaOrder, statusOrder) " \
                  "VALUES (%s,%s,%s,%s,%s,%s)"

            dbc.execute(sql, [id_client, nama_order, desk_order, tgl_order, total_order, stat_order])
            db.commit()

            # dapatkan ID dari data kantin yang baru dimasukkan
            orderID = dbc.lastrowid
            data_orders = {'id':orderID}
            jsondoc = json.dumps(data_orders)

            # simpan menu-menu untuk kantin di atas ke database
            # for i in range(len(data['produk'])):
            #     menu = data['produk'][i]['menu']
            #     price = data['produk'][i]['price']
            #
            #     sql = "INSERT INTO kantin_menu (idresto,menu,price) VALUES (%s,%s,%s)"
            #     dbc.execute(sql, [orderID,menu,price] )
            #     db.commit()


            # Publish event "new kantin" yang berisi data kantin yg baru.
            # Data json yang dikirim sebagai message ke RabbitMQ adalah json asli yang
            # diterima oleh route /kantin [POST] di atas dengan tambahan 2 key baru,
            # yaitu 'event' dan orderID.
            # data['event']  = 'new_order'
            # data['order_id'] = orderID
            # message = json.dumps(data)
            # publish_message(message,'kantin.tenant.new')


            status_code = 201
        # bila ada kesalahan saat insert data, buat XML dengan pesan error
        except mysql.connector.Error as err:
            status_code = 409
    #endregion

    # ------------------------------------------------------
    # Kirimkan JSON yang sudah dibuat ke client
    # ------------------------------------------------------
    resp = HTTPResponse()
    if jsondoc !='': resp.response = jsondoc
    resp.headers['Content-Type'] = 'application/json'
    resp.status = status_code
    return resp


@app.route('/order/<path:id>', methods = ['POST', 'GET', 'PUT', 'DELETE'])
def order2(id):
    jsondoc = ''


    # ------------------------------------------------------
    # HTTP method = GET
    # ------------------------------------------------------
    if HTTPRequest.method == 'GET':
        if id.isnumeric():
            # ambil data kantin
            sql = "SELECT * FROM orders WHERE idOrder = %s"
            dbc.execute(sql, [id])
            data_order = dbc.fetchone()


            if data_order != None:
                jsondoc = json.dumps(data_order, default=str)
                status_code = 200  # The request has succeeded
            else:
                status_code = 404  # No resources found
        else: status_code = 400  # Bad Request


    # ------------------------------------------------------
    # HTTP method = POST
    # ------------------------------------------------------
    # elif HTTPRequest.method == 'POST':
    #     data = json.loads(HTTPRequest.data)
    #     kantinName = data['nama']
    #     gedung = data['gedung']
    #
    #     try:
    #         # simpan nama kantin, dan gedung ke database
    #         sql = "INSERT INTO kantin_resto (id, nama,gedung) VALUES (%s,%s,%s)"
    #         dbc.execute(sql, [id,kantinName,gedung] )
    #         db.commit()
    #         # dapatkan ID dari data kantin yang baru dimasukkan
    #         kantinID = dbc.lastrowid
    #         data_kantin = {'id':kantinID}
    #         jsondoc = json.dumps(data_kantin)
    #
    #         # TODO: Kirim message ke order_service melalui RabbitMQ tentang adanya data kantin baru
    #
    #
    #         status_code = 201
    #     # bila ada kesalahan saat insert data, buat XML dengan pesan error
    #     except mysql.connector.Error as err:
    #         status_code = 409


    # ------------------------------------------------------
    # HTTP method = PUT
    # ------------------------------------------------------
    elif HTTPRequest.method == 'PUT':
        data = json.loads(HTTPRequest.data)

        id_client = data["idClient"]
        nama_order = data["namaOrder"]
        desk_order = data["deskripsiOrder"]
        tgl_order = data["tanggalOrder"]
        total_order = data["totalHargaOrder"]
        stat_order = data["statusOrder"]

        # id = data['id']
        # nama = data['nama']
        # gedung = data['gedung']

        messagelog = 'PUT id: ' + str(id)
        logging.warning("Received: %r" % messagelog)

        try:
            # ubah nama kantin dan gedung di database
            sql = "UPDATE orders SET idClient=%s, namaOrder=%s, deskripsiOrder=%s, tanggalOrder=%s, " \
                  "totalHargaOrder=%s, statusOrder=%s WHERE idOrder=%s"
            dbc.execute(sql, [id_client,nama_order, desk_order, tgl_order, total_order,stat_order,id])
            db.commit()

            # teruskan json yang berisi perubahan data kantin yang diterima dari Web UI
            # ke RabbitMQ disertai dengan tambahan route = 'kantin.tenant.changed'
            data_baru = {}
            data_baru['event']  = "updated_order"
            data_baru['id']     = id
            jsondoc = json.dumps(data_baru)
            # publish_message(jsondoc,'kantin.tenant.changed')

            status_code = 200
        # bila ada kesalahan saat ubah data, buat XML dengan pesan error
        except mysql.connector.Error as err:
            status_code = 409


    # ------------------------------------------------------
    # HTTP method = DELETE
    # ------------------------------------------------------
    elif HTTPRequest.method == 'DELETE':
        # data = json.loads(HTTPRequest.data)
        if id.isnumeric():
            sql = "DELETE FROM orders WHERE idOrder = %s"
            dbc.execute(sql, [id])
            db.commit()

            data_baru = {}
            data_baru['event']  = "deleted_order"
            data_baru['id']     = id
            jsondoc = json.dumps(data_baru)
            status_code = 200  # The request has succeeded

        else: status_code = 400  # Bad Request


    # ------------------------------------------------------
    # Kirimkan JSON yang sudah dibuat ke client
    # ------------------------------------------------------
    resp = HTTPResponse()
    if jsondoc !='': resp.response = jsondoc
    resp.headers['Content-Type'] = 'application/json'
    resp.status = status_code
    return resp





