# library untuk JSON
import json
# library untuk transfer data
import requests

data = {"idOrder": 4,
        "idStaffPIC": 1,
        "namaEvent": "dummyEvent1",
        "deskripsiEvent": "deskDummy1",
        "tanggalEvent": "2023-06-15",
        "jamMulaiEvent": "01:00:00",
        "jamAkhirEvent": "01:30:00",
        "subTotalEvent": 200
        }

jsondoc = json.dumps(data)
response = requests.post('http://localhost:5001/event', data=jsondoc)
if (response.status_code == 201):
    data = response.json()
    print('DATA BERHASIL DITAMBAHKAN')
    print('Kode baru: ' + str(data['id']))
else:
    print('Error Code: ' + str(response.status_code))


