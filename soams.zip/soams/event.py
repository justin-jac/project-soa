from flask import Flask, render_template, Response as HTTPResponse, request as HTTPRequest
import mysql.connector
import mysql.connector, json, pika, logging
from flask_cors import CORS
# from kantin_producer import *

db = mysql.connector.connect(host="localhost", user="root", password="",database="eventdb")
dbc = db.cursor(dictionary=True)


app = Flask(__name__)
CORS(app)
# Note, HTTP response codes are
#  200 = OK the request has succeeded.
#  201 = the request has succeeded and a new resource has been created as a result.
#  401 = Unauthorized (user identity is unknown)
#  403 = Forbidden (user identity is known to the server)
#  409 = A conflict with the current state of the resource
#  429 = Too Many Requests


@app.route('/event', methods = ['POST', 'GET'])
def event():
    jsondoc = ''

    #region GET
    # ------------------------------------------------------
    # HTTP method = GET
    # ------------------------------------------------------
    if HTTPRequest.method == 'GET':
        auth = HTTPRequest.authorization
        print(auth)

        # ambil data kantin
        sql = "SELECT * FROM events"
        dbc.execute(sql)
        data_event = dbc.fetchall()

        if data_event != None:
            # kalau data order ada, juga ambil menu dari kantin tsb.
            # for x in range(len(data_event)):
            #     kantin_id = data_event[x]['id']
            #     sql = "SELECT * FROM orders WHERE idresto = %s"
            #     dbc.execute(sql, [kantin_id])
            #     data_menu = dbc.fetchall()
            #     data_event[x]['produk'] = data_menu

            status_code = 200  # The request has succeeded
            jsondoc = json.dumps(data_event, default=str)
        else:
            status_code = 404  # No resources found
    #endregion

    #region POST
    # ------------------------------------------------------
    # HTTP method = POST
    # ------------------------------------------------------
    elif HTTPRequest.method == 'POST':
        data = json.loads(HTTPRequest.data)

        id_order = data['idOrder']
        id_pic = data['idStaffPIC']
        nama_event = data['namaEvent']
        desk_event = data['deskripsiEvent']
        tanggal_event = data['tanggalEvent']
        jam_mulai = data['jamMulaiEvent']
        jam_akhir = data['jamAkhirEvent']
        sub_total = data['subTotalEvent']

        try:
            # simpan nama kantin, dan gedung ke database
            sql = "INSERT INTO events (idOrder, idStaffPIC, namaEvent, deskripsiEvent, tanggalEvent, jamMulaiEvent, "\
                "jamAkhirEvent, subTotalEvent)  VALUES  (%s,%s,%s,%s,%s,%s,%s,%s)"



            # sql = "INSERT INTO events (nama,gedung) VALUES (%s,%s)"
            dbc.execute(sql, [id_order, id_pic, nama_event, desk_event, tanggal_event, jam_mulai, jam_akhir, sub_total])
            db.commit()
            # dapatkan ID dari data kantin yang baru dimasukkan
            eventID = dbc.lastrowid
            data_event = {'id':eventID}
            jsondoc = json.dumps(data_event)

            # simpan menu-menu untuk kantin di atas ke database
            # for i in range(len(data['produk'])):
            #     menu = data['produk'][i]['menu']
            #     price = data['produk'][i]['price']
            #
            #     sql = "INSERT INTO kantin_menu (idresto,menu,price) VALUES (%s,%s,%s)"
            #     dbc.execute(sql, [eventID,menu,price] )
            #     db.commit()


            # Publish event "new kantin" yang berisi data kantin yg baru.
            # Data json yang dikirim sebagai message ke RabbitMQ adalah json asli yang
            # diterima oleh route /kantin [POST] di atas dengan tambahan 2 key baru,
            # yaitu 'event' dan eventID.
            data['event']  = 'new_event'
            data['event_id'] = eventID
            message = json.dumps(data)
            # publish_message(message,'kantin.tenant.new')


            status_code = 201
        # bila ada kesalahan saat insert data, buat XML dengan pesan error
        except mysql.connector.Error as err:
            status_code = 409


    # ------------------------------------------------------
    # Kirimkan JSON yang sudah dibuat ke client
    # ------------------------------------------------------
    resp = HTTPResponse()
    if jsondoc !='': resp.response = jsondoc
    resp.headers['Content-Type'] = 'application/json'
    resp.status = status_code
    return resp
    #endregion


@app.route('/event/<path:id>', methods = ['POST', 'GET', 'PUT', 'DELETE'])
def event2(id):
    jsondoc = ''


    # ------------------------------------------------------
    # HTTP method = GET
    # ------------------------------------------------------
    if HTTPRequest.method == 'GET':
        if id.isnumeric():
            # ambil data kantin
            sql = "SELECT * FROM events WHERE idEvent = %s"
            dbc.execute(sql, [id])
            data_event = dbc.fetchone()


            if data_event != None:
                jsondoc = json.dumps(data_event, default=str)
                status_code = 200  # The request has succeeded
            else:
                status_code = 404  # No resources found
        else: status_code = 400  # Bad Request


    # ------------------------------------------------------
    # HTTP method = POST
    # ------------------------------------------------------
    # elif HTTPRequest.method == 'POST':
    #     data = json.loads(HTTPRequest.data)
    #     kantinName = data['nama']
    #     gedung = data['gedung']
    #
    #     try:
    #         # simpan nama kantin, dan gedung ke database
    #         sql = "INSERT INTO kantin_resto (id, nama,gedung) VALUES (%s,%s,%s)"
    #         dbc.execute(sql, [id,kantinName,gedung] )
    #         db.commit()
    #         # dapatkan ID dari data kantin yang baru dimasukkan
    #         kantinID = dbc.lastrowid
    #         data_kantin = {'id':kantinID}
    #         jsondoc = json.dumps(data_kantin)
    #
    #         # TODO: Kirim message ke order_service melalui RabbitMQ tentang adanya data kantin baru
    #
    #
    #         status_code = 201
    #     # bila ada kesalahan saat insert data, buat XML dengan pesan error
    #     except mysql.connector.Error as err:
    #         status_code = 409


    # ------------------------------------------------------
    # HTTP method = PUT
    # ------------------------------------------------------
    elif HTTPRequest.method == 'PUT':
        data = json.loads(HTTPRequest.data)

        id_order = data['idOrder']
        id_pic = data['idStaffPIC']
        nama_event = data['namaEvent']
        desk_event = data['deskripsiEvent']
        tanggal_event = data['tanggalEvent']
        jam_mulai = data['jamMulaiEvent']
        jam_akhir = data['jamAkhirEvent']
        sub_total = data['subTotalEvent']

        messagelog = 'PUT id: ' + str(id)
        logging.warning("Received: %r" % messagelog)

        try:
            # ubah nama kantin dan gedung di database
            sql = "UPDATE events SET idOrder=%s, idStaffPIC=%s, namaEvent=%s, deskripsiEvent=%s, tanggalEvent=%s, " \
                  "jamMulaiEvent=%s, jamAkhirEvent=%s, subTotalEvent=%s WHERE idEvent=%s"
            dbc.execute(sql, [id_order, id_pic, nama_event, desk_event, tanggal_event, jam_mulai, jam_akhir, sub_total,id])
            db.commit()

            # teruskan json yang berisi perubahan data kantin yang diterima dari Web UI
            # ke RabbitMQ disertai dengan tambahan route = 'kantin.tenant.changed'
            data_baru = {}
            data_baru['event']  = "updated_event"
            data_baru['id']     = id
            jsondoc = json.dumps(data_baru)
            # publish_message(jsondoc,'kantin.tenant.changed')

            status_code = 200
        # bila ada kesalahan saat ubah data, buat XML dengan pesan error
        except mysql.connector.Error as err:
            status_code = 409


    # ------------------------------------------------------
    # HTTP method = DELETE
    # ------------------------------------------------------
    elif HTTPRequest.method == 'DELETE':
        # data = json.loads(HTTPRequest.data)
        if id.isnumeric():
            sql = "DELETE FROM events WHERE idEvent = %s"
            dbc.execute(sql, [id])
            db.commit()

            data_baru = {}
            data_baru['event']  = "deleted_order"
            data_baru['id']     = id
            jsondoc = json.dumps(data_baru)
            status_code = 200  # The request has succeeded

        else: status_code = 400  # Bad Request


    # ------------------------------------------------------
    # Kirimkan JSON yang sudah dibuat ke client
    # ------------------------------------------------------
    resp = HTTPResponse()
    if jsondoc !='': resp.response = jsondoc
    resp.headers['Content-Type'] = 'application/json'
    resp.status = status_code
    return resp
